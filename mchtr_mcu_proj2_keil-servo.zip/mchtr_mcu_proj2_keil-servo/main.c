#include <aduc834.h>
#include <intx_t.h>
#include <lab2_board.h>
#include <lcd_comm.h>
#include <math.h>

#define F_CPU 12.582912		 	// the core clock frequency in MHz 
														// must be adjusted according to the PLLCON setting
#define T_INIT_1MS (0xFFFF - (uint16_t)(1000 * F_CPU / 12))
#define T_10US ((uint16_t)(10 * F_CPU / 12))

volatile uint32_t system_tick;

void init_system_timer(void)
{
	TH2 = T_INIT_1MS / 256;
	TL2 = T_INIT_1MS % 256;
	RCAP2H = T_INIT_1MS / 256;
	RCAP2L = T_INIT_1MS % 256;
	TR2 = 1;
	ET2 = 1;
}

void isr_timer2(void) interrupt 5
{
	TF2 = 0;
	system_tick++;
}

// 32b variable ms_tick can�t be read in a single instruction; 
// this function implements a solution with rereading
uint32_t get_tick(void)
{
	uint32_t tick_a, tick_b;

	do {
		tick_a = system_tick;
		tick_b = system_tick;
	} while (tick_a != tick_b);

	return tick_a;
}

void delay_ms(uint32_t t_ms)
{
	uint32_t t_ref = get_tick();

	while (get_tick() - t_ref < t_ms) { };
}

/* servos control structure */
struct servo_control {
	uint16_t sv_pw[4]; // servo pulse width * 10 us
	uint16_t sv_pw_calc[4]; 
};

static struct servo_control sv_ctrl;

/* delay definition for the "lcd_comm" module */
void LCD_DelayMs(uint16_t ms_cnt)
{
	delay_ms(ms_cnt);
}

/* formats value as a 3 digit decimal with leading zeros */
void LCD_SendDecimal3(uint16_t val)
{
	val %= 1000;
	_LCD_CHAR(val/100 + '0');
	val %= 100;
	_LCD_CHAR(val/10 + '0');
	val %= 10;
	_LCD_CHAR(val + '0');
}

/* cfg and start timer 1 in 16b mode,
	 enable timer 1 interrupt */
void start_servo_timer ()
{
	TH1 = 0;
	TL1 = 0;
	
	TMOD &= 0x0F;
	TMOD |= 0x10;
	TR1 = 1;
	ET1 = 1;
	PT1 = 1;
}

/* change timer counter value */
void cfg_servo_timer (uint16_t val)
{
	TR1 = 0;

	/* timer 1 is in 16b mode */
	TH1 = (val>>8);
	TL1 = (uint8_t)(val);

	TR1 = 1;
}

static volatile uint8_t stop_timer_flag = 0;

/* stops the servo timer after generating pulses for all servos */
void stop_servo_timer ()
{
	stop_timer_flag = 1;
}

/* sets pulse width of the 'sv_n' servo to 'sv_pw'*10 microseconds */
void set_servo_pw (uint8_t sv_n, uint16_t sv_pw)
{
	if (sv_pw < MIN_PULSE_WIDTH/10) sv_pw = MIN_PULSE_WIDTH/10;
	else if (sv_pw > MAX_PULSE_WIDTH/10) sv_pw = MAX_PULSE_WIDTH/10;
	
	sv_ctrl.sv_pw[sv_n] = sv_pw;
	sv_ctrl.sv_pw_calc[sv_n] = (uint16_t)0xFFFF - sv_pw * T_10US;
}

uint8_t current_servo = 0;

/* servo-handling interrupt 
   higher priority than system clock due to the required high precision of pulse generation */
void t1_isr() interrupt 3
{	
	switch (current_servo++)
	{
		case 0:
			if (stop_timer_flag)
			{
				TR1 = 0;
				ET1 = 0;
				
				// all servo lines LOW
				PORT_SV |= 0xF0;
				
				stop_timer_flag = 0;
				
				break;
			}
			PORT_SV &= ~(1<<SV1);	
			cfg_servo_timer(sv_ctrl.sv_pw_calc[0]);
			break;
			
		case 1:
			PORT_SV |= (1<<SV1);	
			PORT_SV &= ~(1<<SV2);	
			cfg_servo_timer(sv_ctrl.sv_pw_calc[1]);
			break;
		
		case 2:
			PORT_SV |= (1<<SV2);	
			PORT_SV &= ~(1<<SV3);	
			cfg_servo_timer(sv_ctrl.sv_pw_calc[2]);
			break;
		
		case 3:
			PORT_SV |= (1<<SV3);	
			PORT_SV &= ~(1<<SV4);	
			cfg_servo_timer(sv_ctrl.sv_pw_calc[3]);
			break;	
		
		case 4:
			PORT_SV |= (1<<SV4);	
			cfg_servo_timer(0xFFFF - PULSE_REMAINDER_WIDTH/10 * T_10US);
			current_servo = 0;
			break;			
	}
}
					
enum states {ST_INIT, ST_STOP, ST_RUN};					
					
int main (void)
{
	uint8_t i;
	enum states current_state = ST_INIT;
	
	while (1)
	{	
		switch (current_state)
		{
			case ST_INIT:
			{	
				/* servo lines LOW, motor lines OFF */
				P0 = 0xFF;
				P1 &= ~(1<<0);
				
				/* set clock 12.5 MHz */
				PLLCON &= ~0x07;
				
				init_system_timer();
				
				EA = 1;
				
				PORT_LCD_LED &= ~(1<<LCD_RED);
				PORT_LCD_LED |= (1<<LCD_BLUE | 1<<LCD_GREEN);

				LCD_Init();	
				LCD_Byte(0,LCD_CLEAR);
				LCD_SendString("Wait...");
	
				/* init the servo ctrl structure */
				for (i = 0; i < 4; i++)	set_servo_pw(i, 150);
				start_servo_timer();
				delay_ms(400);
				stop_servo_timer();
				delay_ms(100);
				
				PORT_LCD_LED &= ~(1<<LCD_GREEN);
				PORT_LCD_LED |= (1<<LCD_BLUE | 1<<LCD_RED);

				LCD_Byte(0,LCD_CLEAR);
				LCD_SendString("LCD + servo - + A OnOff");
				LCD_Byte(0,LCD_LINE_FOUR);
				LCD_SendString("OK, READY");
				LCD_Byte(0,LCD_LINE_TWO);
				LCD_SendDecimal3(sv_ctrl.sv_pw[0]);

				current_state = ST_STOP;

				break;
			}
			case ST_STOP:
			{
				if (BUTTON5_CHK) 
				{
					while(BUTTON5_CHK);
					delay_ms(250);
					
					LCD_Byte(0,LCD_LINE_FOUR);
					LCD_SendString("RUNNING  ");
					
					start_servo_timer();
					current_state = ST_RUN;
				}
				break;
			}
			case ST_RUN:
			{				
				if (BUTTON5_CHK) 
				{
					while(BUTTON5_CHK);
					delay_ms(250);
					
					LCD_Byte(0,LCD_CLEAR);
					LCD_Byte(0,LCD_LINE_THREE);
					LCD_SendString("- + A OnOff");
					LCD_Byte(0,LCD_LINE_FOUR);
					LCD_SendString("STOPPED  ");
					
					stop_servo_timer();
					current_state = ST_STOP;
				}
				break;
			}
			default:
			{
				stop_servo_timer();
				current_state = ST_STOP;
				break;
			}
		}
		
		
		// decrement
		if (BUTTON2_CHK) 
		{
			for (i = 0; i < 4; i++)	set_servo_pw(i, sv_ctrl.sv_pw[i]-1);
			LCD_Byte(0,LCD_LINE_TWO);
			LCD_SendDecimal3(sv_ctrl.sv_pw[0]);
		}
		// increment
		else if (BUTTON3_CHK)
		{
			for (i = 0; i < 4; i++)	set_servo_pw(i, sv_ctrl.sv_pw[i]+1);
			LCD_Byte(0,LCD_LINE_TWO);
		  LCD_SendDecimal3(sv_ctrl.sv_pw[0]);
		}	
		// auto
		else if (BUTTON4_CHK)
		{
			// 30 positions
			const uint8_t positions[] = {	60, 65, 70, 75, 80, 90, 100, 120, 140, 160, 180, 190, 195, 200, 205, 210,
																		205, 200, 195, 190, 180, 160, 140, 120, 100, 90, 80, 75, 70, 65};
			static uint8_t pos_idx = 0;

			pos_idx++;
			pos_idx %= 30;

			for (i = 0; i < 4; i++)	set_servo_pw(i, positions[pos_idx]);

			LCD_Byte(0,LCD_LINE_TWO);
			LCD_SendDecimal3(sv_ctrl.sv_pw[0]);

			delay_ms(50);
		}
	}	
	
	return 0;
}