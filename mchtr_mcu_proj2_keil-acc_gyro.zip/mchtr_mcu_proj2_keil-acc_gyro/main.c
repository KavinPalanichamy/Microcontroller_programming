#include <aduc834.h>
#include <intx_t.h>
#include <lab2_board.h>
#include <lcd_comm.h>
#include <lsm6ds33_reg.h>
#include <i2c_comm.h>
#include <stdio.h>

#define	ACC_GYRO_ADDR				0x6B

#define F_CPU 12.582912		 	// the core clock frequency in MHz 
														// must be adjusted according to the PLLCON setting
#define T_INIT_1MS (0xFFFF - (uint16_t)(1000 * F_CPU / 12))

volatile uint32_t system_tick;

void init_system_timer(void)
{
	TH2 = T_INIT_1MS / 256;
	TL2 = T_INIT_1MS % 256;
	RCAP2H = T_INIT_1MS / 256;
	RCAP2L = T_INIT_1MS % 256;
	TR2 = 1;
	ET2 = 1;
}

void isr_timer2(void) interrupt 5
{
	TF2 = 0;
	system_tick++;
}

// 32b variable ms_tick can�t be read in a single instruction; 
// this function implements a solution with rereading
uint32_t get_tick(void)
{
	uint32_t tick_a, tick_b;

	do {
		tick_a = system_tick;
		tick_b = system_tick;
	} while (tick_a != tick_b);

	return tick_a;
}

void delay_ms(uint32_t t_ms)
{
	uint32_t t_ref = get_tick();

	while (get_tick() - t_ref < t_ms) { };
}

/* delay definition for the "lcd_comm" module */
void LCD_DelayMs(uint16_t ms_cnt)
{
	delay_ms(ms_cnt);
}

enum states {ST_INIT, ST_ACC_GET};					
					
int main (void)
{
  uint8_t ret;
	uint8_t i2c_buf[10];
	idata char buf[20];
	enum states current_state = ST_INIT;
	
	while (1)
	{	
		switch (current_state)
		{
			case ST_INIT:
			{	
				/* servo lines LOW, motor lines OFF */
				P0 = 0xFF;
				P1 &= ~(1<<0);
				
				/* set clock 12.5 MHz */
				PLLCON &= ~0x07;
				
				init_system_timer();
				
				EA = 1;
				
				PORT_LCD_LED &= ~(1<<LCD_RED);
				PORT_LCD_LED |= (1<<LCD_BLUE | 1<<LCD_GREEN);

				LCD_Init();	
				LCD_Byte(0,LCD_CLEAR);
				LCD_SendString("Wait...");
	
				I2C_Init();
				
				// wait for AccGyro boot
				delay_ms(20);

				ret = I2C_RxData(ACC_GYRO_ADDR, WHO_AM_I, &i2c_buf, 1);
				
				LCD_Byte(0,LCD_LINE_TWO);
				sprintf(buf, "WhoAmI: %02bx", i2c_buf[0]);
				LCD_SendString(buf);
	
				// cfg gyro
				i2c_buf[0] = 0x38;		// enable X,Y,Z axes
				ret = I2C_TxData(ACC_GYRO_ADDR, CTRL10_C, &i2c_buf, 1);
				i2c_buf[0] = 0x14;		// 13 Hz ODR, 500 dps 
				ret = I2C_TxData(ACC_GYRO_ADDR, CTRL2_G, &i2c_buf, 1);
				
				// cfg acc
				i2c_buf[0] = 0x38;		// enable X,Y,Z axes
				ret = I2C_TxData(ACC_GYRO_ADDR, CTRL9_XL, &i2c_buf, 1);
				i2c_buf[0] = 0x18;		// 13 Hz ODR, +/- 4 g
				ret = I2C_TxData(ACC_GYRO_ADDR, CTRL1_XL, &i2c_buf, 1);
			
				delay_ms(3000);
	
				PORT_LCD_LED &= ~(1<<LCD_GREEN);
				PORT_LCD_LED |= (1<<LCD_BLUE | 1<<LCD_RED);

				current_state = ST_ACC_GET;

				break;
			}
			case ST_ACC_GET:
			{
				ret = I2C_RxData(ACC_GYRO_ADDR, STATUS_REG, &i2c_buf, 1);
				if ((i2c_buf[0] & SR_GDA) && (i2c_buf[0] & SR_XLDA))
				{					
					ret = I2C_RxData(ACC_GYRO_ADDR, OUTX_L_G, &i2c_buf, 6);
					LCD_Byte(0,LCD_CLEAR);
					sprintf(buf, "GyrX %04x", (uint16_t)(i2c_buf[1]<<8) + i2c_buf[0]);
					LCD_SendString(buf);
					LCD_Byte(0,LCD_LINE_TWO);
					sprintf(buf, "Y%04x Z%04x", 
								(uint16_t)(i2c_buf[3]<<8) + i2c_buf[2], 
								(uint16_t)(i2c_buf[5]<<8) + i2c_buf[4]);
					LCD_SendString(buf);
					
					ret = I2C_RxData(ACC_GYRO_ADDR, OUTX_L_XL, &i2c_buf, 6);
					LCD_Byte(0,LCD_LINE_THREE);
					sprintf(buf, "AccX %04x", (uint16_t)(i2c_buf[1]<<8) + i2c_buf[0]);
					LCD_SendString(buf);
					LCD_Byte(0,LCD_LINE_FOUR);
					sprintf(buf, "Y%04x Z%04x", 
								(uint16_t)(i2c_buf[3]<<8) + i2c_buf[2], 
								(uint16_t)(i2c_buf[5]<<8) + i2c_buf[4]);
					LCD_SendString(buf);
				}
				delay_ms(200);				

				break;
			}
			default:
			{
				break;
			}
		}
	}	
	
	return 0;
}